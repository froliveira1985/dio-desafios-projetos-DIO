export class alunos {
    nome: string;
    idade: number;
    email: string;
    curso: string;
}