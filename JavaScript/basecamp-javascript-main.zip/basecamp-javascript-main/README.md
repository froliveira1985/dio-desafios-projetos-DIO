# Basecamp Javascript

O basecampt de Javascript é uma iniciativa da [Digital Innovation One](https://digitalinnovation.one/) para ensinar os pilares da linguagem e seus conceitos mais básicos.

Neste repositório, você encontrará as atividades práticas de todos os cursos que ministrei para a iniciativa.
