function paintRed(el) {
	el.style.backgroundColor = 'red';
}

export { paintRed };
