# Imports Dinâmicos

Os imports dinâmicos não foram abordados no curso de "Módulos" porque é necessário que você tenha conhecimento prévio de Javascript Assíncrono. Sendo assim, recomendo que você volte neste repositório após completar o curso de Javascript Assíncrono que também faz parte deste Basecamp.

## Exercício

Este exercício serve apenas como um exemplo de como utilizar módulos **por demanda**. Na nossa página HTML, ao clicar no botão, o fundo da página fica vermelho.

Não se esqueça de utilizar a extensão "Live Server" caso você vá tentar realizar este desafio!
