import { mostraIdade, mostraCidade, mostraHobby } from './funcoes.mjs';

console.log(mostraIdade('Marina', 20));

console.log(mostraCidade('Silvia', 'São Paulo'));

console.log(mostraHobby('Carol', 'Ouvir música'));
